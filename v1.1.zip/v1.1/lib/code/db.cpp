#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

struct Contact {
    string name;
    string phone;
    string email;
};

void addContact(vector<Contact>& contacts) {
    Contact newContact;
    cout << "Enter name: ";
    cin.ignore();
    getline(cin, newContact.name);
    cout << "Enter phone: ";
    getline(cin, newContact.phone);
    cout << "Enter email: ";
    getline(cin, newContact.email);
    contacts.push_back(newContact);
}

void displayContacts(const vector<Contact>& contacts) {
    for(const auto& contact : contacts) {
        cout << "Name: " << contact.name << ", Phone: " << contact.phone << ", Email: " << contact.email << endl;
    }
}

void saveContacts(const vector<Contact>& contacts, const string& filename) {
    ofstream outFile(filename);
    for(const auto& contact : contacts) {
        outFile << contact.name << " , " << contact.phone << " , " << contact.email << endl;
    }
}

void loadContacts(vector<Contact>& contacts, const string& filename) {
    ifstream inFile(filename);
    string line;
    while(getline(inFile, line)) {
        size_t pos1 = line.find(',');
        size_t pos2 = line.find(',', pos1 + 1);
        Contact contact;
        contact.name = line.substr(0, pos1);
        contact.phone = line.substr(pos1 + 1, pos2 - pos1 - 1);
        contact.email = line.substr(pos2 + 1);
        contacts.push_back(contact);
    }
}

int main() {
    vector<Contact> contacts;
    string filename = "contacts.txt";

    loadContacts(contacts, filename);

    int choice;
    do {
        cout << "1. Add Contact" << endl;
        cout << "2. Display Contacts" << endl;
        cout << "3. Save and Exit" << endl;
        cout << "Enter your choice: " << endl;
        cin >> choice;

        switch(choice) {
           case 1:
                addContact(contacts);
                break;
            case 2:
                displayContacts(contacts);
                break;
            case 3:
                saveContacts(contacts, filename);
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while(choice != 3);

    return 0;
}