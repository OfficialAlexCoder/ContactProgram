**IMPORTANT READ ME**

1. Click on the application.exe file and read instructions there,
2. Once you've added a few contacts,
3. Press 3 to save and exit the app,
4. Go to the contacts.txt file and click on it,
5. See your contacts saved.

**NOTE**

Ignore the lib folder in the current version you are using - version 1.0 -
Ignore the .vscode folder that's there for the code to work using VSCode editor.